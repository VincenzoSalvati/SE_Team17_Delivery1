create definer = root@localhost view skill_need_view as
select `n`.`skill` AS `skill`, `n`.`specifications` AS `specifications`
from `project`.`need` `n`
         join `project`.`skill` `s`
where (`s`.`id` = `n`.`skill`);

