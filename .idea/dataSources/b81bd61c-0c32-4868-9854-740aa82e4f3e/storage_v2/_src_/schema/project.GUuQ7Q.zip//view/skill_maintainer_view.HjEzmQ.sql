create definer = root@localhost view skill_maintainer_view as
select `m`.`name` AS `name`, `m`.`id` AS `id`, `c`.`skill` AS `skill`
from `project`.`maintainer` `m`
         join `project`.`capacity` `c`
where (`m`.`id` = `c`.`maintainer`);

